﻿
package com.sc.signature;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;

import com.sci.androidsignature.R;


public class MainActivity extends Activity
{
	EditText edit = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_main);
		
		// 显示签名信息
		edit = (EditText) this.findViewById(R.id.edit);
		String sign = SignTool.getSignature(this);
		edit.setText(sign);
		
		SignTool.CheckSign(this);	// 检测应用签名，不匹配则自动退出
	}
}
